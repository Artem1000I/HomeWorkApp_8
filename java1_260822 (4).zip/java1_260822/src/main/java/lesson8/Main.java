package lesson8;

public class Main {
    public static void main(String[] args) {
        new ApplicationForm("Calculator v1.0 beta");
    }
}
